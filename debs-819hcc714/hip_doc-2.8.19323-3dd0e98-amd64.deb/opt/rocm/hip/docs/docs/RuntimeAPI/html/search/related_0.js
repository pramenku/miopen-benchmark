var searchData=
[
  ['hipeventrecord',['hipEventRecord',['../classihipEvent__t.html#a553b6f7a8e7b7dd9536d8a64c24d7e29',1,'ihipEvent_t']]],
  ['hipstreamquery',['hipStreamQuery',['../classihipStream__t.html#a46bba2e3bfbb0915a08fb608aed31858',1,'ihipStream_t']]]
];
