var searchData=
[
  ['warpsize',['warpSize',['../structhipDeviceProp__t.html#af3357d33c004608bf05bc21a352be81b',1,'hipDeviceProp_t']]],
  ['wavefrontsize',['WavefrontSize',['../structAMDGPU_1_1RuntimeMD_1_1IsaInfo_1_1Metadata.html#ae69ceec94853e590f2789f5c0d87df43',1,'AMDGPU::RuntimeMD::IsaInfo::Metadata']]]
];
