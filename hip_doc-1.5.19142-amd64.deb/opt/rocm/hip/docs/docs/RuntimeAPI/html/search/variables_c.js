var searchData=
[
  ['pcibusid',['pciBusID',['../structhipDeviceProp__t.html#a1350f64d49b717ed3a06458f7549ccb0',1,'hipDeviceProp_t']]],
  ['pcideviceid',['pciDeviceID',['../structhipDeviceProp__t.html#ae6aa845dc2d540f85098ea30be35f4eb',1,'hipDeviceProp_t']]],
  ['pcidomainid',['pciDomainID',['../structhipDeviceProp__t.html#aa0f598c0196ff1f429290a43c1fa4038',1,'hipDeviceProp_t']]]
];
