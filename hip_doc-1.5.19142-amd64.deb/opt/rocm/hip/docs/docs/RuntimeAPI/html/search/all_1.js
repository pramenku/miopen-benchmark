var searchData=
[
  ['addressablenumsgprs',['AddressableNumSGPRs',['../structAMDGPU_1_1RuntimeMD_1_1IsaInfo_1_1Metadata.html#aee651209d269015eaff356bfaedc0003',1,'AMDGPU::RuntimeMD::IsaInfo::Metadata']]],
  ['addressablenumvgprs',['AddressableNumVGPRs',['../structAMDGPU_1_1RuntimeMD_1_1IsaInfo_1_1Metadata.html#a78ae88390d0e502dc021ed4ee7af4d5d',1,'AMDGPU::RuntimeMD::IsaInfo::Metadata']]],
  ['agent_5fglobal',['Agent_global',['../structAgent__global.html',1,'']]],
  ['amdgpuptnote_2eh',['AMDGPUPTNote.h',['../AMDGPUPTNote_8h.html',1,'']]],
  ['amdgpuruntimemetadata_2eh',['AMDGPURuntimeMetadata.h',['../AMDGPURuntimeMetadata_8h.html',1,'']]],
  ['api_5fcallbacks_5ftable_5ft',['api_callbacks_table_t',['../classapi__callbacks__table__t.html',1,'']]],
  ['api_5fcallbacks_5ftable_5ftempl',['api_callbacks_table_templ',['../classapi__callbacks__table__templ.html',1,'']]],
  ['arch',['arch',['../structhipDeviceProp__t.html#afc58158e44bef6ad26f2be401434b049',1,'hipDeviceProp_t']]],
  ['av',['av',['../structgrid__launch__parm.html#a9bc1b5657ed852899355fa31a692d9ea',1,'grid_launch_parm']]]
];
