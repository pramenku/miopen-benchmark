var searchData=
[
  ['barrier_5fbit',['barrier_bit',['../structgrid__launch__parm.html#aad0a298878d5e27e9575e59022925425',1,'grid_launch_parm']]]
];
