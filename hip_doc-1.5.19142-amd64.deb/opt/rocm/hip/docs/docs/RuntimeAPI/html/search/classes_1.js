var searchData=
[
  ['agent_5fglobal',['Agent_global',['../structAgent__global.html',1,'']]],
  ['api_5fcallbacks_5ftable_5ft',['api_callbacks_table_t',['../classapi__callbacks__table__t.html',1,'']]],
  ['api_5fcallbacks_5ftable_5ftempl',['api_callbacks_table_templ',['../classapi__callbacks__table__templ.html',1,'']]]
];
