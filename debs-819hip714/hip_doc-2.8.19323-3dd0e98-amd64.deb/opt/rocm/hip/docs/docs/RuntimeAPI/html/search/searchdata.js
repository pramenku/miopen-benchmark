var indexSectionsWithContent =
{
  0: "_abcdefghilmnprstuvwxyz",
  1: "_acdfghilmpstu",
  2: "adhl",
  3: "h",
  4: "_abcdefghilmnprstvwxyz",
  5: "dh",
  6: "h",
  7: "h",
  8: "h",
  9: "_",
  10: "cdefghilms",
  11: "bdh"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "defines",
  10: "groups",
  11: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends",
  9: "Macros",
  10: "Modules",
  11: "Pages"
};

