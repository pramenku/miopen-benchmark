var searchData=
[
  ['x',['X',['../structCoordinates_1_1X.html',1,'Coordinates']]]
];
