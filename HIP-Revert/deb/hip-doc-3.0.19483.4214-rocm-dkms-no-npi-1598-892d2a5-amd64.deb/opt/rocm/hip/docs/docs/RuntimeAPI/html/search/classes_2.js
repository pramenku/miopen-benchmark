var searchData=
[
  ['coordinates',['Coordinates',['../structCoordinates.html',1,'']]]
];
