var searchData=
[
  ['y',['Y',['../structCoordinates_1_1Y.html',1,'Coordinates']]],
  ['y',['y',['../structdim3.html#a83e60e072f7e8bdfde6ac05053cbb370',1,'dim3']]]
];
