var searchData=
[
  ['gcnarch',['gcnArch',['../structhipDeviceProp__t.html#adc5950a3d5bbe00cf59d413d8aeeee18',1,'hipDeviceProp_t']]],
  ['gl_5fdim3',['gl_dim3',['../structgl__dim3.html',1,'']]],
  ['global_20enum_20and_20defines',['Global enum and defines',['../group__GlobalDefs.html',1,'']]],
  ['grid_5fdim',['grid_dim',['../structgrid__launch__parm.html#a12ce262c26d2f51fdf4d6f8c36028ec6',1,'grid_launch_parm']]],
  ['grid_5flaunch_5fparm',['grid_launch_parm',['../structgrid__launch__parm.html',1,'']]],
  ['griddim',['gridDim',['../structhipLaunchParams__t.html#a1be220830ac317422384d4bd9758eba1',1,'hipLaunchParams_t']]],
  ['group_5fdim',['group_dim',['../structgrid__launch__parm.html#a871bfb7642bb36b02d1693aaff5f7f2a',1,'grid_launch_parm']]],
  ['groupid',['GroupId',['../structhip__impl_1_1GroupId.html',1,'hip_impl']]],
  ['groupsize',['GroupSize',['../structhip__impl_1_1GroupSize.html',1,'hip_impl']]]
];
