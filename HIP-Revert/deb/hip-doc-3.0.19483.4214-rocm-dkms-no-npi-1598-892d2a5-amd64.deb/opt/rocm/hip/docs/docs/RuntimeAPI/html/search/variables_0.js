var searchData=
[
  ['_5fcomputeunits',['_computeUnits',['../classihipDevice__t.html#a655e03136394df32571a52707aa371c5',1,'ihipDevice_t']]]
];
