var searchData=
[
  ['name',['name',['../structhipDeviceProp__t.html#a5b44bf8fa46faefcde989942b1d11a5e',1,'hipDeviceProp_t']]],
  ['numgroups',['NumGroups',['../structhip__impl_1_1NumGroups.html',1,'hip_impl']]]
];
