var searchData=
[
  ['integrated',['integrated',['../structhipDeviceProp__t.html#ac0350a226dc71cc01fb3708b523b0061',1,'hipDeviceProp_t']]],
  ['ipc_5fhandle',['ipc_handle',['../classihipIpcMemHandle__t.html#af2142ab7d9f820acbad7638428509d42',1,'ihipIpcMemHandle_t']]],
  ['ismultigpuboard',['isMultiGpuBoard',['../structhipDeviceProp__t.html#a9bb19b2b0cdee8977ed63964532d639d',1,'hipDeviceProp_t']]]
];
