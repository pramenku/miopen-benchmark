var searchData=
[
  ['kernelexectimeoutenabled',['kernelExecTimeoutEnabled',['../structhipDeviceProp__t.html#abdc2c1af9bf2b27f7faf892bb18d34f1',1,'hipDeviceProp_t']]]
];
