var searchData=
[
  ['sgprallocgranule',['SGPRAllocGranule',['../structAMDGPU_1_1RuntimeMD_1_1IsaInfo_1_1Metadata.html#a59321d0e0a0c6f53e3e7f24b76540082',1,'AMDGPU::RuntimeMD::IsaInfo::Metadata']]],
  ['sharedmem',['sharedMem',['../structhipLaunchParams__t.html#a0a6f0e39516c631fd792c8c5f37cedfb',1,'hipLaunchParams_t']]],
  ['sharedmemperblock',['sharedMemPerBlock',['../structhipDeviceProp__t.html#a3b9138678a0795c2677eddcfb1c67156',1,'hipDeviceProp_t']]],
  ['stream',['stream',['../structhipLaunchParams__t.html#a43da36b3985165bb697aa5ea0d8ebef3',1,'hipLaunchParams_t']]]
];
