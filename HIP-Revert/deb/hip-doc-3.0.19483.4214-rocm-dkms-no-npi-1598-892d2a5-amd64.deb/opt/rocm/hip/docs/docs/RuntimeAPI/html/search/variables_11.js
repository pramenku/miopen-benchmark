var searchData=
[
  ['tccdriver',['tccDriver',['../structhipDeviceProp__t.html#af38ab98291566293bd4dad46314e0d9f',1,'hipDeviceProp_t']]],
  ['texturealignment',['textureAlignment',['../structhipDeviceProp__t.html#a5c55ab4144841d785ac31de0eb823060',1,'hipDeviceProp_t']]],
  ['totalconstmem',['totalConstMem',['../structhipDeviceProp__t.html#a29880232c56120be3455ce00d5379665',1,'hipDeviceProp_t']]],
  ['totalglobalmem',['totalGlobalMem',['../structhipDeviceProp__t.html#acedd6a2d23423441e4bf51c4a1b719f9',1,'hipDeviceProp_t']]],
  ['totalnumsgprs',['TotalNumSGPRs',['../structAMDGPU_1_1RuntimeMD_1_1IsaInfo_1_1Metadata.html#ae2dd8daa224661b1b3e7c48b1da0f991',1,'AMDGPU::RuntimeMD::IsaInfo::Metadata']]],
  ['totalnumvgprs',['TotalNumVGPRs',['../structAMDGPU_1_1RuntimeMD_1_1IsaInfo_1_1Metadata.html#a5d797813d1d748c0ec8a0f4c049a035d',1,'AMDGPU::RuntimeMD::IsaInfo::Metadata']]]
];
