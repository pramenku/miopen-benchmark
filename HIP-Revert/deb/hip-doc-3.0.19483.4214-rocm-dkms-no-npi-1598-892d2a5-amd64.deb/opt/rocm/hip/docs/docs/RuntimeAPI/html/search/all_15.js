var searchData=
[
  ['x',['X',['../structCoordinates_1_1X.html',1,'Coordinates']]],
  ['x',['x',['../structdim3.html#ac866c05f83a28dac20a153fc65b3b16c',1,'dim3']]]
];
