/* ************************************************************************
 * Copyright 2016 Advanced Micro Devices, Inc.
 * ************************************************************************ */

/* the configured version and settings
 */
#ifndef ROCSOLVER_VERSION_H_
#define ROCSOLVER_VERSION_H_

// clang-format off
#define ROCSOLVER_VERSION_MAJOR 2
#define ROCSOLVER_VERSION_MINOR 7
#define ROCSOLVER_VERSION_PATCH 0
#define ROCSOLVER_VERSION_TWEAK 55-rocm-dkms-no-npi-1598-0157c19
// clang-format on

#endif
