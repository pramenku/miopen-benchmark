var searchData=
[
  ['coordinates',['Coordinates',['../classCoordinates.html',1,'']]]
];
