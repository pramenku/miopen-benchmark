var searchData=
[
  ['launch_20api_20to_20support_20the_20triple_2dchevron_20syntax',['Launch API to support the triple-chevron syntax',['../group__Clang.html',1,'']]]
];
