var searchData=
[
  ['_5f_5fattribute_5f_5f',['__attribute__',['../group__Memory.html#ga7503ec9e58559fb589214755c9b93a25',1,'hip_runtime_api.h']]]
];
