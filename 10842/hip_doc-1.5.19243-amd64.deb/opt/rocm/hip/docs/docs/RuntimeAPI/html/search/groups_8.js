var searchData=
[
  ['management',['Management',['../group__Context.html',1,'']]],
  ['memory_20management',['Memory Management',['../group__Memory.html',1,'']]]
];
