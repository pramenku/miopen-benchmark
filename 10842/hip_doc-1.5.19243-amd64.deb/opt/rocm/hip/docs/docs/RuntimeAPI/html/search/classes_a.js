var searchData=
[
  ['proftrigger',['ProfTrigger',['../structProfTrigger.html',1,'']]]
];
